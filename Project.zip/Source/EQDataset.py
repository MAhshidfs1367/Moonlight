import os

import pandas as pd


class Dataset:
    def __init__(self, file_name, file_name_clean):
        """
        Initializes the Dataset class.

        Parameters:
        - file_name (str): Path to the raw dataset file.
        - file_name_clean (str): Path to the cleaned dataset file.
        """
        self.file_name = file_name
        self.file_name_clean = file_name_clean
        self.data = None

    def post_process(self, df):
        """
        Add a 'year' column to the DataFrame based on the 'date_time' column.

        Parameters:
        - df (pd.DataFrame): The DataFrame to process.
        """
        df["year"] = pd.to_datetime(
            df["date_time"], format="%d-%m-%Y %H:%M"
        ).dt.year

    def load_data_raw(self):
        """
        Load and clean the raw dataset.

        Returns:
        - pd.DataFrame: The cleaned dataset.
        """
        df_raw = pd.read_csv(self.file_name)

        print(df_raw.describe())
        print(df_raw.shape)
        print(df_raw.isnull().sum())

        drop_indices = []
        n = len(df_raw)

        for i, row in enumerate(df_raw.itertuples()):
            country = row.country
            continent = row.continent

            lookup_country, lookup_continent = None, None
            if self.is_empty(row.country) or self.is_empty(row.continent):
                print(f"{country}, {continent}")
                lookup_country, lookup_continent = (
                    self.lookup_country_and_continent(
                        country, row.latitude, row.longitude
                    )
                )
                print(
                    f"lookup ({row.latitude}, {row.longitude}) = {lookup_country}, {lookup_continent}"
                )
                if (
                    not self.is_empty(country)
                    and self.is_empty(lookup_country)
                ) or (
                    not self.is_empty(continent)
                    and self.is_empty(lookup_continent)
                ):
                    print(
                        f"*** Fix: {country} | {lookup_country}, {continent} | {lookup_continent}"
                    )

            if self.is_empty(country):
                country = lookup_country

            if self.is_empty(continent):
                continent = lookup_continent

            if self.is_empty(country) or self.is_empty(continent):
                drop_indices.append(i)

            print(f"{i} of {n} completed.")

        print(f"{len(drop_indices)} samples will be dropped.")
        df = df_raw.drop(drop_indices)

        self.post_process(df)

        self.reindex_df(df)
        df.drop(
            list(
                np.where(
                    np.logical_or(
                        pd.isna(df["country"]), pd.isna(df["continent"])
                    )
                    == True
                )[0]
            ),
            inplace=True,
        )
        self.reindex_df(df)

        df.to_csv(self.file_name_clean, index=False)

        self.data = df
        return df

    def load_data_clean(self):
        """
        Load the cleaned dataset.

        Returns:
        - pd.DataFrame: The cleaned dataset.
        """
        df = pd.read_csv(self.file_name_clean)

        if "Unnamed: 0" in df.columns:
            df.drop("Unnamed: 0", axis=1, inplace=True)

        self.post_process(df)
        self.data = df
        return df

    def load_data(self):
        """
        Load data based on availability. If a clean data file exists, it loads clean data; otherwise, it processes raw data.

        Returns:
            pd.DataFrame: The loaded data, either clean or raw.
        """
        df = None
        if os.path.exists(self.file_name_clean):
            print("Loading clean data...")
            df = self.load_data_clean()
            print("Loading finished.")
        else:
            print("Loading raw data...")
            df = self.load_data_raw()
            print("Loading finished.")
        return df

    @staticmethod
    def is_empty(value):
        """
        Check if a value is empty or None.

        Parameters:
        - value: The value to check.

        Returns:
        - bool: True if the value is empty, False otherwise.
        """
        return pd.isna(value) or value == "" or value == None

    @staticmethod
    def get_continent(country_name_raw):
        """
        Retrieve the continent name for a given country name.

        Args:
            country_name_raw (str): The raw name of the country.

        Returns:
            str: The continent name corresponding to the given country.
        """
        return get_cn_continent(country_name_raw)[1]

    @staticmethod
    def lookup_country_and_continent(country, lat, lon):
        """
        Lookup the country and continent based on the provided country name, latitude, and longitude.

        Args:
            country (str): The initial country name (may be raw or unverified).
            lat (float): The latitude of the location.
            lon (float): The longitude of the location.

        Returns:
            tuple: A tuple containing the verified country name (or 'Unknown') and the corresponding continent name.

        Notes:
            - If the country is already mapped in the `co_cn_map`, it retrieves the corresponding continent.
            - Otherwise, it uses geopy's `Nominatim` to reverse-geocode the latitude and longitude to get the country and continent.
            - The function handles exceptions gracefully and returns (None, None) if an error occurs.
        """
        if country in co_cn_map:
            return country, co_cn_map[country]

        geolocator = Nominatim(user_agent="geo_locator")
        try:
            location = geolocator.reverse(
                (lat, lon), exactly_one=True, language="en"
            )
            if location:
                address = location.raw.get("address", {})
                country = address.get("country", "Unknown")
                continent = address.get(
                    "continent", "Unknown"
                )  # Not all geopy data provides continent directly

                if not continent:
                    continent_code = address.get("ISO3166-1:alpha3")[:2]
                    continent = continent_lookup.get(continent_code, "Unknown")

                return country, get_continent(country)
            else:
                return None, None
        except Exception as e:
            print(f"Error: {e}")
            return None, None

    @staticmethod
    def reindex_df(df):
        """
        Reindex the DataFrame.

        Parameters:
        - df (pd.DataFrame): The DataFrame to reindex.
        """
        df.reset_index(inplace=True)
        df.drop("index", axis=1, inplace=True)
