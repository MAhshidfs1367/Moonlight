import matplotlib.pyplot as plt
import seaborn as sns

"""
High Positive Correlations: sig and cdi (0.52):There is 
a strong positive correlation between the maximum 
reported intensity (cdi) and the significance 
score (sig). This indicates that earthquakes reported 
with higher community intensity tend to be classified 
as more significant events, which makes sense since 
reported intensity contributes to the event's overall 
significance.sig and magnitude (0.44): The magnitude of 
the earthquake and its significance are moderately 
correlated, showing that larger earthquakes are generally 
perceived as more impactful or significant. cdi and 
magnitude (0.25): There is a weaker but notable correlation 
between the earthquake's magnitude and the maximum reported 
intensity (cdi), suggesting that magnitude partially 
influences the reported intensity felt by the community.
Strong Negative Correlations:mmi and depth (-0.76): A very 
strong negative correlation exists between the maximum 
estimated instrumental intensity (mmi) and the depth of the 
earthquake. This suggests that shallower earthquakes produce 
stronger instrumental intensity readings, as deeper earthquakes 
lose energy before reaching the surface.cdi and 
nst (-0.37): The number of seismic stations used (nst) 
and the maximum reported intensity (cdi) are negatively 
correlated. This could indicate that events reported with 
high community intensity often have fewer seismic stations 
contributing to their location determination.
Low or Near-Zero Correlations:nst and magnitude (-0.01): The 
number of stations (nst) used to determine the earthquake 
location shows no meaningful correlation with the earthquake's 
magnitude. gap and depth (-0.13):
There is a weak negative correlation between azimuthal 
gap (gap) and depth, suggesting that the reliability of 
station coverage has little influence on earthquake depth. 
tsunami: Not directly visualized here, but it's important to 
consider that this binary feature (1 for oceanic events, 0 
otherwise) might add further insights when combined with magnitude 
or depth in a separate analysis.
"""


def draw(df):
    target_numric_columns = [
        "magnitude",
        "cdi",
        "mmi",
        "sig",
        "net",
        "nst",
        "dmin",
        "gap",
        "depth",
    ]

    corr_matrix = df.loc[:, target_numric_columns].corr(numeric_only=True)

    plt.figure(figsize=(10, 6))

    sns.heatmap(corr_matrix, annot=True, fmt=".2f", cmap="coolwarm", cbar=True)

    plt.title("Correlation Heatmap of Earthquake Features")

    plt.show()
