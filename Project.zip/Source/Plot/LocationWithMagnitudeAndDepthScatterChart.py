import matplotlib.pyplot as plt

"""
Geographical Distribution:
Most earthquakes are clustered around specific 
regions, indicating seismically active zones like 
the Pacific Ring of Fire.Latitude ranges between 
approximately -40 to 60, and longitude spreads 
across the entire globe.
Magnitude:
Higher magnitudes (yellow-green circles) are 
scattered across the map, particularly in areas 
with high seismic activity.Lower magnitudes (purple) 
are more frequent and dispersed.
Tsunami Events:
Larger circles appear prominently in certain regions 
(e.g., near Oceania or tectonic boundaries), signifying 
the association between high-magnitude earthquakes and 
tsunami generation. Smaller circles dominate the data, 
showing that most earthquakes do not trigger tsunamis.
"""


def draw(df):
    # Select relevant columns: 'latitude', 'longitude', 'magnitude', and 'depth'
    data = df[["tsunami", "latitude", "longitude", "magnitude", "depth"]]

    # Create a scatter plot using Seaborn
    plt.figure(figsize=(10, 6))

    # Plot with latitude and longitude on axes, depth as color, magnitude as size
    scatter = plt.scatter(
        data["latitude"],
        data["longitude"],
        c=data["magnitude"],
        s=(data["tsunami"] + 0.3) * 300,  # scale size for visibility
        cmap="viridis",
        alpha=0.7,
        edgecolors="w",
        linewidth=0.5,
    )

    # Customize plot
    plt.title("Earthquake Location with Magnitude and Depth")
    plt.xlabel("latitude")
    plt.ylabel("longitude")

    # Add color bar for depth
    plt.colorbar(
        scatter,
        label="Magnitude (km) \n Size is tsunami [Small: no, big: yes ]",
    )

    # Show plot
    plt.grid(True)
    plt.show()
