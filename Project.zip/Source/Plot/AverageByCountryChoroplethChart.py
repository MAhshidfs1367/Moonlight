import EQLocation as eql
import numpy as np
import pandas as pd
import plotly.express as px


class ACCChart:

    def __init__(self, df, file_name_filtered_2022):
        df_magnitude = list(
            np.where(pd.notnull(df.loc[:, "magnitude"]).values == True)[0]
        )

        df.iloc[df_magnitude]

        df_magnitude_filtered = df.loc[
            df_magnitude, ["country", "magnitude", "depth", "year"]
        ]

        df_magnitude_filtered = df_magnitude_filtered.fillna(0)

        countries = set(df_magnitude_filtered.country)
        years = set(df_magnitude_filtered.year)

        df_magnitude_filtered_groupby_country = df_magnitude_filtered.groupby(
            "country"
        )

        years_countries = dict()

        for country in countries:

            country_years = list(
                df_magnitude_filtered_groupby_country.get_group(country).year
            )

            for year in years:

                if year not in years_countries:

                    years_countries[year] = []

                if year in country_years:

                    years_countries[year].append(country)

        df_magnitude_filtered_2022 = df_magnitude_filtered[
            df_magnitude_filtered.year == 2022
        ]

        with open(file_name_filtered_2022, mode="w") as f:

            f.write(
                '"country","continent","year","value","depth","mag_over_dep","iso_alpha"\n'
            )

        countries_magnitude = dict()

        with open(file_name_filtered_2022, mode="a+") as f:

            for group in df_magnitude_filtered_2022.groupby("country"):

                country_name = group[0]

                average_magnitude = np.average(group[1].magnitude.values)

                average_depth = np.average(group[1].depth.values)

                f.write(
                    f'"{country_name}","{eql.get_cn_continent(country_name)[1]}",2022,{average_magnitude},{average_depth},{average_magnitude/average_depth},"{eql.get_cn_continent(country_name)[0]}"\n'
                )

        data = pd.read_csv(file_name_filtered_2022)

        self._data = data

    """
    Average magnitude by country in 2022:
    The color scale represents the earthquake magnitude, with purple 
    indicating lower values and yellow showing the highest values (7.6 on the scale).
    Highest Magnitude Countries: The country in yellow (likely Papua 
    New Guinea) stands out with an average magnitude of 7.6. Moderate 
    Magnitude: Countries such as Mexico and parts of Southeast Asia 
    (e.g., Indonesia) are in red/pink, indicating moderately high 
    magnitudes.Lower Magnitude: Countries like Brazil, China, and 
    parts of South America are shaded in purple, indicating relatively 
    lower average magnitudes, closer to 6.6–6.8.
    """

    def draw_magnitude(self):
        fig = px.choropleth(
            self._data,
            locations="iso_alpha",
            color="value",
            hover_name="country",
            projection="natural earth",
            animation_frame="year",
            title="Average magnitude by country in 2022",
        )

        fig.show()

    """
    Average depth by country in 2022:  
    This choropleth map visualizes the average earthquake 
    depth (in kilometers) by country in 2022.
    The color scale on the right ranges from dark blue 
    (lower depths) to yellow (higher depths), with maximum 
    depths reaching 600 km. Highest Average Depths:Countries 
    in yellow have the deepest earthquakes on average.
    Notably, Brazil and its neighboring regions in South America 
    show 600 km as the average depth, suggesting very deep seismic 
    activity. Moderate Depths: Areas in purple and pink, such as 
    Argentina and other parts of South America, have moderate 
    average earthquake depths (200–400 km). Shallow Depths:Countries 
    shaded in dark blue like China, Mexico, and parts of Southeast 
    Asia (e.g., Indonesia, Philippines) exhibit shallower earthquakes 
    with depths below 100 km.
    """

    def draw_depth(self):
        fig = px.choropleth(
            self._data,
            locations="iso_alpha",
            color="depth",
            hover_name="country",
            projection="natural earth",
            animation_frame="year",
            title="Average depth by country in 2022",
        )

        fig.show()

    """
    Average magnitude over depth by country in 2022:
    The color bar on the right represents the "average 
    magnitude over depth" (mag_over_dep) ranging from 
    dark blue (low) to yellow (high). China: This 
    country stands out with a bright yellow color, 
    indicating it has the highest average magnitude 
    over depth, South America (e.g., Brazil/Chile): 
    Countries in this region are colored in dark blue, 
    representing the lowest values of average magnitude 
    over depth and Mexico and Indonesia: These regions 
    appear in reddish-pink and purple shades, meaning 
    their average magnitude over depth falls in the 
    middle of the scale.
    """

    def draw_magnitude_over_depth(self):
        fig = px.choropleth(
            self._data,
            locations="iso_alpha",
            color="mag_over_dep",
            hover_name="country",
            projection="natural earth",
            animation_frame="year",
            title="Average magnitude over depth by country in 2022",
        )

        fig.show()
