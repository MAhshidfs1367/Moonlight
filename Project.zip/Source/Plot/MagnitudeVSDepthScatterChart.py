import matplotlib.pyplot as plt

"""
Magnitude Distribution:
The magnitude values range approximately between 6.5 
and 8.5, with a majority of events clustered around 
6.5 to 7.5.There are very few earthquakes with a 
magnitude greater than 8.0, highlighting their rarity 
in the dataset.
Depth Distribution:
The depth values are concentrated primarily between 0 
and 100 kilometers.However, there are a notable number 
of deeper earthquakes exceeding 200 km, with a few 
events reaching depths greater than 600 km.
"""


def draw(df):
    plt.figure(figsize=(8, 6))

    plt.scatter(
        df["magnitude"], df["depth"], alpha=0.7, c="blue", edgecolor="k"
    )

    plt.title("Scatter Plot of Magnitude vs Depth")
    plt.xlabel("Magnitude")
    plt.ylabel("Depth")

    plt.grid(True)

    plt.show()
