import matplotlib.pyplot as plt

"""
Across all three countries, the average earthquake magnitudes 
are high, often between 6.0 to 7.0, which classifies them as 
significant seismic events. Mexico: Periodic occurrences with 
gaps, Ecuador: Sparse years with significant magnitudes and 
Japan: Consistent seismic activity year after year.
"""


def draw(df):
    _nrows = 1
    _ncols = 3

    fig, ax = plt.subplots(nrows=1, ncols=3, figsize=(15, 4))

    COUNTRIES = ["Mexico", "Ecuador", "Japan"]

    plt.suptitle(f"Average Magnitude of Countries", fontweight="bold")

    for i, COUNTRY in enumerate(COUNTRIES):

        plt.subplot(_nrows, _ncols, i + 1)

        plt.title(COUNTRY.capitalize())

        df_country = df[df.country == COUNTRY]

        df_country_filtered = df_country.loc[:, ["magnitude", "year"]].dropna()
        df_country_filtered = df_country_filtered[
            df_country_filtered.year > 2000
        ]
        df_country_filtered_mean = df_country_filtered.groupby("year").mean()

        years = [int(year) for year in df_country_filtered_mean.index]

        magnitude_means = [int(v) for v in df_country_filtered_mean.values]

        if i == 0:
            plt.ylabel("Average Magnitude", fontweight="bold")
        plt.xlabel("Year", fontweight="bold")

        plt.xticks(range(min(years), max(years) + 3, 3))

        plt.bar(years, magnitude_means)

    plt.show()
