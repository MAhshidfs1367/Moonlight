import os

file_name = os.path.join("archive", "earthquake_data.csv")
file_name_clean = os.path.join("archive", "earthquake_data_clean.csv")

file_name_filtered_2022 = os.path.join(
    "archive", "earthquake_data_clean_filtered-2022.csv"
)

print("file_name:", file_name)
print("file_name_clean:", file_name_clean)
