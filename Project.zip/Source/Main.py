"""
Author: Mahshid
Date: 16 December, 2024
-----------------------
EarthQuake

Earthquakes, powerful natural disasters, can occur 
suddenly and without warning. Most of the time, they 
result from the movement of tectonic plates in the 
Earth's crust,releasing a significant amount of 
energy in the form of seismic waves.Powerful earthquakes 
can result in extensive harm to buildings and infrastructure, 
causing loss of life and property. To learn more about 
earthquakes and get ready for them, scientists have 
made a list of important earthquakes.The Important 
Earthquake Database has info like where earthquakes occurred, 
how strong they were, when they happened, and if they 
caused tsunamis. 

The Data
The data I am working with is from 
https://www.kaggle.com/code/ravivarmaodugu/earthquakes-data-analytics 
which has information about 782 Earthquake events that have
taken place around the world between 1/1/2001 and 1/1/2023.

"""

import EQConstant as eqc
import EQDataset as eqd
from Plot import AverageByCountryChoroplethChart as accc
from Plot import AverageMagnitudeOfCountriesBarChart as amcbc
from Plot import CorrelationOfFeaturesHeatmapChart as cfhc
from Plot import LocationWithMagnitudeAndDepthScatterChart as lmdsc
from Plot import MagnitudeVSDepthScatterChart as mdsc

dataset = eqd.Dataset(eqc.file_name, eqc.file_name_clean)
df = dataset.load_data()

accc_chart = accc.ACCChart(df, eqc.file_name_filtered_2022)
accc_chart.draw_magnitude()
accc_chart.draw_depth()
accc_chart.draw_magnitude_over_depth()

amcbc.draw(df)

cfhc.draw(df)

mdsc.draw(df)

lmdsc.draw(df)
