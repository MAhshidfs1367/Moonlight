import pycountry_convert as pc

continents = {
    "NA": "North America",
    "SA": "South America",
    "AS": "Asia",
    "OC": "Australia",
    "AF": "Africa",
    "EU": "Europe",
}

# Use a fallback for the continent if it's not present
continent_lookup = {
    "Africa": "Africa",
    "Asia": "Asia",
    "Europe": "Europe",
    "North America": "North America",
    "South America": "South America",
    "Oceania": "Oceania",
    "Antarctica": "Antarctica",
}

co_cn_map = {
    "Antarctica": "Antarctica",
    "United Kingdom of Great Britain and Northern Ireland (the)": "Europe",
    "South Georgia and the South Sandwich Islands": "South America",
    "Chile": "South America",
    "Mexico": "North America",
    "United States of America": "North America",
}


def get_cn_continent(country_name_raw):
    country_name = country_name_raw.split("(")[0].strip().lower()
    country_name = country_name[0].upper() + country_name[1:]
    country_name_words = country_name.split()
    if len(country_name_words) > 1:
        country_name = ""
        for i, word in enumerate(country_name_words):
            if word != "of":
                current_word = word[0].upper() + word[1:]
                if i != 0:
                    country_name += " " + current_word
                else:
                    country_name += current_word
            else:
                country_name += " of"
    if country_name in ["Usa", "Usa Territory"]:
        country_name = "United States of America"
    country_code = pc.country_name_to_country_alpha2(
        country_name, cn_name_format="default"
    )
    continent_name = pc.country_alpha2_to_continent_code(country_code)
    #     if country_name == "United States of America":
    #         continent_name = "USA"
    alpha3_code = pc.country_name_to_country_alpha3(
        country_name, cn_name_format="default"
    )
    return alpha3_code, continents[continent_name]
